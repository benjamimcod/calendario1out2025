const express = require('express')
const {Sequelize, DataTypes, Op, DATE} = require('sequelize')
const app = express()
app.use(express.json())

//conexão com o banco
const sequelize = new Sequelize('escola', 'root', 'escola', {
    host: 'localhost',
    dialect: 'mysql',
    logging: false //evitar logs no terminal
})

//Modelo(tabelas)
const Feriado = sequelize.define('Feriado', {
    id:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey:true
    },
    data:{
        type: DataTypes.DATEONLY,
        allowNull: false,
        unique: true,
        validate:{is: /^\d{4}-\d{2}-\d{2}$/} //YYYY-MM-DD
    },
    nome:{
        type:DataTypes.STRING(255),
        allowNull: false,
        set(v){this.setDataValue('nome', String(v || '').trim())}
    }
}, {tableName: 'feriados', timestamps:false});

function toISO(d){
    return new Date(d).toISOString().slice(0, 10)
}

function validarDataISO(data) {
 if (!/^\d{4}-\d{2}-\d{2}$/.test(data))  { return false;}
 return toISO(new Date(data)) === data;
}


//criação das Rotas

/*
1- Pesquisar o que é e como funciona o ASYNC AWAIT
ASYNC espera algum evento para acontecer e AWAIT espera algo terminar para continuar
2- O que faz o Operador  Op.Substring
No sequelize pesquisa todas as string que tenha no BD a mesma combinação digitada, ex: "ben"  
3- O que faz o Operador Op.gte
Op.gte => maior ou igual e Op.gt => maior que
4- Por que a validação da data(validarDataISO) é importante?
Que erros poderiam acontecer se ela não existisse?(FOI EXPLICADO)
5- Como funciona o TRY/CATCH? Por que temos que usar?
*/

//Rota GET- para mmostrar todos os feriados - select * from
app.get('/feriados', async (req, res) =>{
    const feriados = await Feriado.findAll({order:[['data', 'ASC'/*ordenar datas em ordem crescente*/]]})
    res.json({feriados})
})

//Buscar por nome(contém)
app.get('/feriado/nome:nome', async (req, res) => {
    const nome = (req.params.nome || '').trim()
    if(!nome) return res.status(400).json({erro: 'informe um nome'});

    const feriado = await Feriado.findOne({
        where: {nome: {[Op.substring]:nome}},
        order: [['data', 'ASC']]
    })
    feriado ? res.json(feriado) : res.status(404).json({erro: 'Feriado não encontrado'})
})

//Prox feriado
app.get('/feriado/proximo', async (req, res) => {
    const hoje = toISO(new Date())
    const proximo = await Feriado.findOne({
        where: {data: {[Op.gte]: hoje}},
        order: [['data', 'ASC']]
    })
    if(!proximo) return res.json({mensagem: 'nenhum feriado futuro'});
    const dias = Math.ceil((new DATE(proximo.data) - new Date())/(1000*60*60*24))
    res.json({...proximo.toJSON()}, dias)
})

//Rota POST

app.post("/cadastroFeriado", async(req, res)=>{
    const {data, nome} = req.body || {};
    
    if(!data || !nome){
        return res.status(400).json({erro: "Data inválida. Use o formato YYYY-MM-DD"})
    }
    const iso = toISO(data)
    if(!validarDataISO(iso)){
        return res.status.json({erro: "Data inválida. Use o formato YYYY-MM-DD"})
    }
    try{
        const novo = await Feriado.create({data: iso, nome: String(nome).trim()})
    }catch(e){
        if(String(e).includes('ER_DUP_ENTRY')){
            return res.status(409).json({erro: 'Já existe feriado nesta data'})
        }
        res.status(500).json({erro: "Falha ao cadastrar", detalhe: String(e)});
    }
})

//CRIAR a rota PUT "Atualizar"(buscar pela data da URL)

app.put("/feriado/:data", async (req, res) => {
    const { data } = req.params
    const { novaData } = req.body

    if (!data || !validarDataISO(data)) {
        return res.status(400).json({ erro: "Data inválida. Use o formato YYYY-MM-DD" })
    }
})